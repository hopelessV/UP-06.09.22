﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rh2021_2022
{
    public partial class Form1 : Form
    {
        DataBase1 data = new DataBase1();
        public Form1()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }


        private string number = "";
        private string pass = "";
        private int ID;
        private void button2_Click(object sender, EventArgs e)
        {
            var Number = textBox1.Text;
            var Pass = textBox2.Text.GetHashCode().ToString();
            var morepas = textBox3.Text.GetHashCode().ToString();


            bool check = false;

            if (textBox1.Text.Length > 11 || textBox2.Text.Length > 0)
            {
                check = true;
            }
            else
            {
                check = false;
                MessageBox.Show("Данные введены не верно или заполнены не все поля", "INFO"); 
            }

            if (check == true)
            {
                data.openConnection();
                var Acc = new SqlCommand($"SELECT * FROM [Account] WHERE number = '{Number}' AND passvord = '{Pass}' ", data.GetConnection());
                var ReadAcc = Acc.ExecuteReader();
                while (ReadAcc.Read())
                {
                    ID = Convert.ToInt32(ReadAcc.GetValue(0));
                    
                }
                ReadAcc.Close();
               
            }

            Random rand = new Random();
            int f = rand.Next(1000, 9999);
            string s = Convert.ToString(f);

            MessageBox.Show($"Данные введены правильно вот ваш код для подтверждения авторизации {s} ", "INFO");

            bool checkall = false;

            if (textBox1.Text.Length > 0 || textBox2.Text.Length > 0 || textBox3.Text.Length > 4)
            {
                checkall = true;
                MessageBox.Show("Авторизация прошла успешно. Программа готова к работе", "INFO");
            }
            else
            {
                MessageBox.Show("Поля заполнены не корректно");
            }

            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();




        }
    }
}
