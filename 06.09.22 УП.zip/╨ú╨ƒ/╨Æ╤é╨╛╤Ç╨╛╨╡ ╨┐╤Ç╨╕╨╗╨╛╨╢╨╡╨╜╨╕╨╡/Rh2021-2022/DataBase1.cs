﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Rh2021_2022
{
    internal class DataBase1
    {
        public static SqlConnection MyCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Владелец\Desktop\ПервоеПриложение\bin\Debug\Harda.mdf;Integrated Security=True;Connect Timeout=30");

        public void openConnection()
        {
            if (MyCon.State == System.Data.ConnectionState.Closed)
            {
                MyCon.Open();
            }
        }

        public void closeConnection()
        {
            if (MyCon.State == System.Data.ConnectionState.Open)
            {
                MyCon.Close();
            }
        }

        public SqlConnection GetConnection()
        {
            return MyCon;
        }
    }
}
