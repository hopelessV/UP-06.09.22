﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ПервоеПриложение
{
    public partial class Form1 : Form
    {

        //инициализация класса с потключением к базе 
        DataBase1 data = new DataBase1();

        public Form1()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
        /// <summary>
        /// Вывод данных из базы данных
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            #region настройка размера формы в зависимости от выбранной вкладки
            //Form1 f1 = new Form1();

            //if (tabPage1 != null)
            //{
            //    this.Refresh();
            //    f1.Size = new Size(508, 636);
            //    this.Refresh();
            //}
            //else if (tabPage2 != null)
            //{
            //    f1.Size = new Size(598, 636);
            //    this.Refresh();
            //}
            //else if (tabPage3 != null)
            //{
            //    f1.Size = new Size(853, 636);
            //    this.Refresh();
            //}
            //else
            //{
            //    f1.Size = new Size(822, 636);
            //    this.Refresh();
            //}
            #endregion
            
            #region вывод данных в dataGridView под определённую страницу
            data.openConnection();
            //Вывод даных для определённого открытого окна
            if(tabControl1.SelectedTab == tabPage1)
            {
                var AddVievHard = new SqlCommand($"SELECT * FROM [ViewHardware]", data.GetConnection());
                var ReadVievHard = AddVievHard.ExecuteReader();
                while (ReadVievHard.Read())
                {
                    dataGridView1.Rows.Add(ReadVievHard["ID_View"], ReadVievHard["name"]);
                }
                ReadVievHard.Close();
            }
            else if (tabControl1.SelectedTab == tabPage2)
            {
                var AddHard = new SqlCommand($"SELECT * FROM [Hardware] ", data.GetConnection());
                var ReadHard = AddHard.ExecuteReader();
                while (ReadHard.Read())
                {
                    dataGridView2.Rows.Add(ReadHard["ID_Hardware"], ReadHard["ID_View"], ReadHard["MAC_Adress"],
                                           ReadHard["IP_Adress"], ReadHard["Number"], ReadHard["IDStatus"]);
                }
                ReadHard.Close();
            }
            else if (tabControl1.SelectedTab == tabPage3)
            {
                var AddIssHard = new SqlCommand($"SELECT * FROM [IssuanceHardware]", data.GetConnection());
                var ReadIssHard = AddIssHard.ExecuteReader();
                while (ReadIssHard.Read())
                {
                    dataGridView3.Rows.Add(ReadIssHard["IDHardware"], ReadIssHard["AdressInstall"], ReadIssHard["IDKlient"],
                                           ReadIssHard["DateInstall"], ReadIssHard["DateIssuance"]);
                }
                ReadIssHard.Close();
            }
            else if (tabControl1.SelectedTab == tabPage4)
            {
                var AddClient = new SqlCommand($"SELECT * FROM [Client]", data.GetConnection());
                var ReadClient = AddClient.ExecuteReader();
                while(ReadClient.Read())
                {
                    dataGridView4.Rows.Add(ReadClient["IDClient"], ReadClient["Surrname"], ReadClient["Name"], ReadClient["Number"]);
                }
                ReadClient.Close();
            }
            else
            {
                var AddStatus = new SqlCommand($"SELECT * FROM [Status]", data.GetConnection());
                var ReadClient = AddStatus.ExecuteReader();
                while (ReadClient.Read())
                {
                    dataGridView5.Rows.Add(ReadClient["IDStatus"], ReadClient["name"]);
                }
                ReadClient.Close();
            }
            data.closeConnection();
            #endregion
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }
    }
}
