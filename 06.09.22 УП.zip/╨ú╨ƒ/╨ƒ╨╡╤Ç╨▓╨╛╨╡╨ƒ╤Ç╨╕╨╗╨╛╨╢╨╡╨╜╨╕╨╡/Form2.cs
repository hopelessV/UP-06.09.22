﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПервоеПриложение
{
    public partial class Form2 : Form
    {
        DataBase1 data = new DataBase1();
        public Form2()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

            #region вывод данных в dataGridView под определённую страницу
            data.openConnection();

            if (tabControl1.SelectedTab == tabPage1)
            {
                var AddVievHard = new SqlCommand($"SELECT * FROM [ViewHardware]", data.GetConnection());
                var ReadVievHard = AddVievHard.ExecuteReader();
                while (ReadVievHard.Read())
                {
                    dataGridView1.Rows.Add(ReadVievHard["ID_View"], ReadVievHard["name"]);
                }
                ReadVievHard.Close();
            }
            else if (tabControl1.SelectedTab == tabPage2)
            {
                var AddHard = new SqlCommand($"SELECT * FROM [Hardware] ", data.GetConnection());
                var ReadHard = AddHard.ExecuteReader();
                while (ReadHard.Read())
                {
                    dataGridView2.Rows.Add(ReadHard["ID_Hardware"], ReadHard["ID_View"], ReadHard["MAC_Adress"],
                                           ReadHard["IP_Adress"], ReadHard["Number"], ReadHard["IDStatus"]);
                }
                ReadHard.Close();
            }
            else if (tabControl1.SelectedTab == tabPage3)
            {
                var AddIssHard = new SqlCommand($"SELECT * FROM [IssuanceHardware]", data.GetConnection());
                var ReadIssHard = AddIssHard.ExecuteReader();
                while (ReadIssHard.Read())
                {
                    dataGridView3.Rows.Add(ReadIssHard["IDHardware"], ReadIssHard["AdressInstall"], ReadIssHard["IDKlient"],
                                           ReadIssHard["DateInstall"], ReadIssHard["DateIssuance"]);
                }
                ReadIssHard.Close();
            }
            else if (tabControl1.SelectedTab == tabPage4)
            {
                var AddClient = new SqlCommand($"SELECT * FROM [Client]", data.GetConnection());
                var ReadClient = AddClient.ExecuteReader();
                while (ReadClient.Read())
                {
                    dataGridView4.Rows.Add(ReadClient["IDClient"], ReadClient["Surrname"], ReadClient["Name"], ReadClient["Number"]);
                }
                ReadClient.Close();
            }
            else
            {
                var AddStatus = new SqlCommand($"SELECT * FROM [Status]", data.GetConnection());
                var ReadClient = AddStatus.ExecuteReader();
                while (ReadClient.Read())
                {
                    dataGridView5.Rows.Add(ReadClient["IDStatus"], ReadClient["name"]);
                }
                ReadClient.Close();
            }
            #endregion
        }
        /// <summary>
        /// Добавление данных в бд с видами оборудования
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            var name = textBox1.Text;

            bool check = false;

            if (textBox1.Text.Length > 0)
            {
                check = true;

            }
            else
            {
                check = false;
                MessageBox.Show("Поле не заполнено", "INFO");
            }

            if (check == true)
            {
                var AddViewHard = new SqlCommand($"INSERT INTO [ViewHardware] (name) VALUES ( '{name}' )", data.GetConnection());
                var ReadViewHard = AddViewHard.ExecuteReader();
                while (ReadViewHard.Read())
                {
                    dataGridView1.Rows.Add(ReadViewHard["ID_View"], ReadViewHard["name"]);
                }
                ReadViewHard.Close();

                MessageBox.Show("Данные были успешно добавлены", "INFO");
            }
        }

        /// <summary>
        /// Изменение данных в бд с видами оборудования
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            var name = textBox1.Text;

            bool check = false;

            if (textBox1.Text.Length > 0)
            {
                check = true;

            }
            else
            {
                check = false;
                MessageBox.Show("Вы не ввели данные для изменения", "INFO");
            }


            if (check == true)
            {
                var UpdateViewHard = new SqlCommand($"UPDATE [ViewHardware] SET (name) = '{name}' ", data.GetConnection());
                var UpReadViewHard = UpdateViewHard.ExecuteReader();
                int i = 0;
                while (UpReadViewHard.Read())
                {
                    var update = UpReadViewHard.GetValue(0);
                    dataGridView1.Rows.Add(update);
                }
                i++;
                UpReadViewHard.Close();
            }
        }
        /// <summary>
        /// Добавление данных в бд с оборудованием
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            var IDView = textBox2.Text;
            var MACAdress = textBox3.Text;
            var IPAdress = textBox4.Text;
            var Number = textBox5.Text;
            var Status = textBox6.Text;

            bool check = false;

            if (textBox2.Text.Length > 0 || textBox3.Text.Length > 0 || textBox4.Text.Length > 0 ||
                textBox5.Text.Length > 0 || textBox6.Text.Length > 0 )
            {
                check = true;
            }
            else
            {
                check = false;
                MessageBox.Show("Поля не были заполнены", "INFO");
            }

            if (check == true)
            {
                var AddHard = new SqlCommand($"INSRT INTO [Hardware] ( ID_View, MAC_Adress, IP_Adress, Number, IDStatus ) " +
                                         $"VALUES ( '{IDView}', '{MACAdress}', '{IPAdress}', '{Number}', '{Status}' )", data.GetConnection());
                var ReadHard = AddHard.ExecuteReader();
                while (ReadHard.Read())
                {
                    dataGridView2.Rows.Add(ReadHard["ID_Hardware"], ReadHard["ID_View"], ReadHard["MAC_Adress"],
                                           ReadHard["IP_Adress"], ReadHard["Number"], ReadHard["IDStatus"]);
                }
                MessageBox.Show("Данные были успешно добавлены", "INFO");
                ReadHard.Close();
            }
        }

        /// <summary>
        /// Изменение данных в бд с оборудованием
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            var IDView = textBox2.Text;
            var MACAdress = textBox3.Text;
            var IPAdress = textBox4.Text;
            var Number = textBox5.Text;
            var Status = textBox6.Text;

            bool check = false;

            if (textBox2.Text.Length > 0 || textBox3.Text.Length > 0 || textBox4.Text.Length > 0 ||
                textBox5.Text.Length > 0 || textBox6.Text.Length > 0)
            {
                check = true;
            }
            else
            {
                check = false;
                MessageBox.Show("Поля не были заполнены", "INFO");
            }
            
            if (check == true)
            {
                var UpdateHard = new SqlCommand($"UPDATE [Hardware] SET ( ID_View, MAC_Adress, IP_Adress, Number, IDStatus ) " +
                                                $" = '{IDView}', '{MACAdress}', '{IPAdress}', '{Number}', '{Status}' ", data.GetConnection());
                var UpReadHard = UpdateHard.ExecuteReader();
                int i = 0;
                while (UpReadHard.Read())
                {
                    var UPDATE = UpReadHard.GetValue(0);
                    dataGridView2.Rows.Add(UPDATE);
                }
                i++;
                UpReadHard.Close();
            }
        }

        /// <summary>
        /// Добавление данных в бд с выданным оборудованием
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button6_Click(object sender, EventArgs e)
        {
            var AdressInst = textBox7.Text;
            var Name = textBox8.Text;
            var DateInst = textBox9.Text;
            var DateIss = textBox10.Text;

            bool check = false;

            if (textBox7.Text.Length > 0 || textBox7.Text.Length > 0 || textBox7.Text.Length == 8 || textBox7.Text.Length == 8)
            {
                check = true;
            }
            else
            {
                check = false;
                MessageBox.Show("Поля не были заполнены", "INFO");
            }

            if (check == true)
            {
                var AddIssHard = new SqlCommand($"INSERT INTO [IssuanceHardware] ( AdressInstall, IDClient, DateInstall, DateIssuance )" +
                                                $"VALUES ( '{AdressInst}', '{Name}', '{DateInst}', '{DateIss}' )", data.GetConnection());
                var ReadIssHard = AddIssHard.ExecuteReader();
                while (ReadIssHard.Read())
                {
                    dataGridView3.Rows.Add(ReadIssHard["IDHardware"], ReadIssHard["AdressInstall"], ReadIssHard["IDClient"],
                                           ReadIssHard["DateInstall"], ReadIssHard["DateIssuance"]);
                }
                
                MessageBox.Show("Данные были успешно добавлены", "INFO");
                ReadIssHard.Close();
            }
        }

        /// <summary>
        /// Изменение данных в бд с выданным оборудованием
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button5_Click(object sender, EventArgs e)
        {
            var AdressInst = textBox7.Text;
            var Name = textBox8.Text;
            var DateInst = textBox9.Text;
            var DateIss = textBox10.Text;

            bool check = false;

            if (textBox7.Text.Length > 0 || textBox7.Text.Length > 0 || textBox7.Text.Length == 8 || textBox7.Text.Length == 8)
            {
                check = true;
            }
            else
            {
                check = false;
                MessageBox.Show("Поля не были заполнены", "INFO");
            }

            if(check == true)
            {
                var UpdateIssHard = new SqlCommand($"UPDATE [IssuanceHardware] SET ( AdressInstall, IDClient, DateInstall, DateIssuance ) " +
                                                   $"= '{AdressInst}', '{Name}', '{DateInst}', '{DateIss}'", data.GetConnection());
                var UpReadIssHard = UpdateIssHard.ExecuteReader();
                int i = 0;
                while (UpReadIssHard.Read())
                {
                    var update = UpReadIssHard.GetValue(0);
                    dataGridView3.Rows.Add(update);
                }
                i++;
                UpReadIssHard.Close();
            }
        }

        /// <summary>
        /// Добавление данных в бд с клиентами
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button8_Click(object sender, EventArgs e)
        {
            var SurrNam = textBox11.Text;
            var Name = textBox12.Text;
            var Number = textBox13.Text;

            bool check = false;

            if (textBox11.Text.Length > 0 || textBox12.Text.Length > 0 || textBox13.Text.Length == 11)
            {
                check = true;
            }
            else
            {
                check = false;
                MessageBox.Show("Поля не были заполнены", "INFO");
            }

            if (check == true)
            {
                var AddClient = new SqlCommand($"INSERT INTO [Client] ( Surrname, Name, Number ) VALUES ( '{SurrNam}', '{Name}', '{Number}' )", data.GetConnection());
                var ReadClient = AddClient.ExecuteReader();
                while (ReadClient.Read())
                {
                    dataGridView4.Rows.Add(ReadClient["IDClient"], ReadClient["Surrname"], ReadClient["Name"], ReadClient["Number"]);
                }
                MessageBox.Show("Данные были успешно сохранены", "INFO");
                ReadClient.Close();
            }
        }

        /// <summary>
        /// Изменение данных в бд с клиентами
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button7_Click(object sender, EventArgs e)
        {
            var SurrNam = textBox11.Text;
            var Name = textBox12.Text;
            var Number = textBox13.Text;

            bool check = false;

            if (textBox11.Text.Length > 0 || textBox12.Text.Length > 0 || textBox13.Text.Length == 11)
            {
                check = true;
            }
            else
            {
                check = false;
                MessageBox.Show("Поля не были заполнены", "INFO");
            }

            if (check == true)
            {
                var UpdateClient = new SqlCommand($"UPDATE [Client] SET ( Surrname, Name, Number ) = '{SurrNam}', '{Name}', '{Number}' ", data.GetConnection());
                var UpReadClient = UpdateClient.ExecuteReader();
                int i = 0;
                while (UpReadClient.Read())
                {
                    var Update = UpReadClient.GetValue(0);
                    dataGridView4.Rows.Add(Update);
                }
                i++;
                UpReadClient.Close();
            }
        }

        /// <summary>
        /// Добавление данных в бд со статусами
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button10_Click(object sender, EventArgs e)
        {
            var name = textBox14.Text;

            bool check = false;

            if (textBox14.Text.Length > 0)
            {
                check = true;
            }
            else
            {
                check = false;
                MessageBox.Show("Данные поля не были заполнены", "INFO");
            }

            if(check == true)
            {
                var AddStatus = new SqlCommand($"INSERT INTO [Status] ( name ) VALUES ( '{name}' )", data.GetConnection());
                var ReadStatus = AddStatus.ExecuteReader();
                while (ReadStatus.Read())
                {
                    dataGridView5.Rows.Add(ReadStatus["IDStatus"], ReadStatus["name"]);
                }
                MessageBox.Show("Данные были сохранены", "INFO");
                AddStatus.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Изменение данных в бд со статусами
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button9_Click(object sender, EventArgs e)
        {
            var name = textBox14.Text;

            bool check = false;

            if (textBox14.Text.Length > 0)
            {
                check = true;
            }
            else
            {
                check = false;
                MessageBox.Show("Данные поля не были заполнены", "INFO");
            }

            if (check == true)
            {
                var UpdateStatus = new SqlCommand($"UPDATE [Status] SET ( name ) = '{name}' ", data.GetConnection());
                var UpReadStatus = UpdateStatus.ExecuteReader();
                int i = 0;
                while (UpReadStatus.Read())
                {
                    var Update = UpReadStatus.GetValue(0);
                    dataGridView5.Rows.Add(Update);
                }
                i++;
                UpReadStatus.Close();
            }
        }
    }
}
